package net.sf.l2j.gameserver.data.xml;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.l2j.commons.data.xml.IXmlReader;

import net.sf.l2j.gameserver.model.actor.Npc;
import net.sf.l2j.gameserver.model.actor.Player;
import net.sf.l2j.gameserver.model.multisell.Entry;
import net.sf.l2j.gameserver.model.multisell.Ingredient;
import net.sf.l2j.gameserver.model.multisell.ListContainer;
import net.sf.l2j.gameserver.model.multisell.PreparedListContainer;
import net.sf.l2j.gameserver.network.serverpackets.MultiSellList;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;

/**
 * This class loads and stores multisell lists under {@link ListContainer}.<br>
 * Each ListContainer contains a List of {@link Entry}, and the list of allowed npcIds.<br>
 * <br>
 * File name is used as key, under its String hashCode.
 */
public class MultisellData implements IXmlReader
{
	public static final int PAGE_SIZE = 40;
	
	private final Map<Integer, ListContainer> _entries = new HashMap<>();
	
	public MultisellData()
	{
		load();
	}
	
	@Override
	public void load()
	{
		parseFile("./data/xml/multisell");
		LOGGER.info("Loaded {} multisell.", _entries.size());
	}
	
	@Override
	public void parseDocument(Document doc, Path path)
	{
		final int id = path.toFile().getName().replaceAll(".xml", "").hashCode();
		final ListContainer list = new ListContainer(id);
		forEach(doc, "list", listNode ->
		{
			final NamedNodeMap attrs = listNode.getAttributes();
			
			list.setApplyTaxes(parseBoolean(attrs, "applyTaxes", false));
			list.setMaintainEnchantment(parseBoolean(attrs, "maintainEnchantment", false));
			
			forEach(listNode, "item", itemNode ->
			{
				final List<Ingredient> ingredients = new ArrayList<>();
				final List<Ingredient> products = new ArrayList<>();
				forEach(itemNode, "ingredient", ingredientNode -> ingredients.add(new Ingredient(parseAttributes(ingredientNode))));
				forEach(itemNode, "production", productionNode -> products.add(new Ingredient(parseAttributes(productionNode))));
				list.getEntries().add(new Entry(ingredients, products));
			});
			forEach(listNode, "npcs", npcsNode -> forEach(npcsNode, "npc", npcNode -> list.allowNpc(Integer.parseInt(npcNode.getTextContent()))));
			
			_entries.put(id, list);
		});
	}
	
	public void reload()
	{
		final Map<Integer, ListContainer> backup = new HashMap<>(_entries);
		_entries.clear();
		try
		{
			load();
			if (_entries.isEmpty())
			{
				_entries.putAll(backup);
				throw new IllegalStateException("Multisell reload aborted: 0 lists parsed.");
			}
		}
		catch (RuntimeException e)
		{
			if (_entries.isEmpty())
				_entries.putAll(backup);
			throw e;
		}
	}
	
	/**
	 * Send the correct multisell content to a {@link Player}.<br>
	 * <br>
	 * {@link ListContainer} template is first retrieved, based on its name, then {@link Npc} npcId check is done for security reason. Then the content is sent into {@link PreparedListContainer}, notably to check Player inventory. Finally a {@link MultiSellList} packet is sent to the Player. That
	 * new, prepared list is kept in memory on Player instance, mostly for memory reason.
	 * @param listName : The ListContainer list name.
	 * @param player : The Player to check.
	 * @param npc : The Npc to check (notably used for npcId check).
	 * @param inventoryOnly : if true we check inventory content.
	 */
	public void separateAndSend(String listName, Player player, Npc npc, boolean inventoryOnly)
	{
		final ListContainer template = _entries.get(listName.hashCode());
		if (template == null)
			return;
		
		if (!template.isCommunityBoardMultisell() && !player.isCMultisell())
		{
			if ((npc != null && !template.isNpcAllowed(npc.getNpcId())) || (npc == null && template.isNpcOnly()))
				return;
		}
		
		final PreparedListContainer list = new PreparedListContainer(template, inventoryOnly, player, npc);
		
		int index = 0;
		do
		{
			// send list at least once even if size = 0
			player.sendPacket(new MultiSellList(list, index));
			index += PAGE_SIZE;
		}
		while (index < list.getEntries().size());
		
		player.setMultiSell(list);
	}
	
	public ListContainer getList(String listName)
	{
		return _entries.get(listName.hashCode());
	}
	
	/**
	 * @param listName multisell file name without .xml (ej: "20000")
	 * @return internal list id used by client packets (filename hashCode)
	 */
	public static int getListHash(String listName)
	{
		return listName.hashCode();
	}
	
	public static MultisellData getInstance()
	{
		return SingletonHolder.INSTANCE;
	}
	
	private static class SingletonHolder
	{
		protected static final MultisellData INSTANCE = new MultisellData();
	}
}