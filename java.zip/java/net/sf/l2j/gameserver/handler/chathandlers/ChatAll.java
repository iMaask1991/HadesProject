package net.sf.l2j.gameserver.handler.chathandlers;

import java.util.StringTokenizer;

import net.sf.l2j.gameserver.handler.IChatHandler;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.handler.VoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.Player;
import net.sf.l2j.gameserver.network.FloodProtectors;
import net.sf.l2j.gameserver.network.FloodProtectors.Action;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.clientpackets.Say2;
import net.sf.l2j.gameserver.network.serverpackets.CreatureSay;

public class ChatAll implements IChatHandler
{
	private static final int[] COMMAND_IDS =
	{
		0
	};
	
	@Override
	public void handleChat(int type, Player activeChar, String params, String text)
	{
		if (!FloodProtectors.performAction(activeChar.getClient(), Action.GLOBAL_CHAT))
		{
			activeChar.sendMessage("Espera un momento antes de volver a escribir.");
			return;
		}

		boolean vcd_used = false;
		if (text.startsWith("."))
		{
		StringTokenizer st = new StringTokenizer(text);
		IVoicedCommandHandler vch;
		String command = "";
		if (st.countTokens() > 1)
		{
			command = st.nextToken().substring(1);
			params = text.substring(command.length() + 2);
			vch = VoicedCommandHandler.getInstance().getHandler(command);
		}
		else
		{
			command = text.substring(1);
			vch = VoicedCommandHandler.getInstance().getHandler(command);
		}
					
		if (vch != null)
		{
			vch.useVoicedCommand(command, activeChar, params);
			vcd_used = true;
		}
		}

		if (!vcd_used)
		{		
			if (activeChar.isHwidChatBanned())
			{
				if (((activeChar.getChatBanTimer() - System.currentTimeMillis()) / 1000) >= 60)
					activeChar.sendChatMessage(0, Say2.TELL, "SYS", "Tu chat fue suspendido por " + (activeChar.getChatBanTimer() - System.currentTimeMillis()) / (1000 * 60) + " minuto(s).");
				else
					activeChar.sendChatMessage(0, Say2.TELL, "SYS", "Tu chat fue suspendido por " + (activeChar.getChatBanTimer() - System.currentTimeMillis()) / 1000 + " segundo(s).");

				activeChar.sendPacket(SystemMessageId.YOU_ARE_NOT_AUTHORIZED_TO_DO_THAT);
				return;
			}
			else if (text.equals("Thanks for using my stuff - Elfocrash"))
				return;
			else if (activeChar.isInArenaEvent() && !activeChar.isArenaAttack())
			{
				activeChar.sendMessage("Wait for the battle to begin..");
				return;
			}
			else if (activeChar.isEventObserver())
			{
				activeChar.sendMessage("You can not do that...");
				return;
			}
			
		final CreatureSay cs = new CreatureSay(activeChar.getObjectId(), type, activeChar.getName(), text);
		final CreatureSay csFake = activeChar.isEventDisguised() ? new CreatureSay(activeChar.getObjectId(), type, net.sf.l2j.gameserver.events.eventgear.EventGearConfig.FAKE_NAME, text) : null;
		for (Player player : activeChar.getKnownTypeInRadius(Player.class, 1250))
			player.sendPacket((csFake != null && net.sf.l2j.gameserver.events.eventgear.EventGearManager.hideFor(activeChar, player)) ? csFake : cs);
		
		activeChar.sendPacket(cs);
		}
	}
	
	@Override
	public int[] getChatTypeList()
	{
		return COMMAND_IDS;
	}
}